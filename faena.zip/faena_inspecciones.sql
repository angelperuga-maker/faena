create extension if not exists pgcrypto;

create table if not exists faena_inspecciones (
  id uuid primary key default gen_random_uuid(),
  equipo text not null,
  code text,
  suscripcion_id uuid,
  solicitud_id uuid,
  tecnico text,
  estado_general text not null default 'operativo',
  resumen text,
  checklist jsonb not null default '[]',
  fecha date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists idx_insp_code  on faena_inspecciones(code);
create index if not exists idx_insp_fecha on faena_inspecciones(fecha);

alter table faena_inspecciones enable row level security;
drop policy if exists "demo all inspecciones" on faena_inspecciones;
create policy "demo all inspecciones" on faena_inspecciones for all using (true) with check (true);

update faena_planes set precio = 139000, beneficios = array['1 inspección mensual en terreno','Checklist documentado por equipo','Prioridad estándar','5% dcto en reparaciones'] where nombre = 'Preventivo Básico';
update faena_planes set precio = 259000, beneficios = array['2 inspecciones + cambio de fluidos','Checklist + reporte de salud','Despacho prioritario < 4 h','10% dcto en reparaciones'] where nombre = 'Preventivo Pro';
update faena_planes set precio = 129000 where nombre = 'Flota Total';

do $$
begin
  if not exists (select 1 from faena_inspecciones) then
    insert into faena_inspecciones (equipo, code, tecnico, estado_general, resumen, checklist, fecha) values
      ('Excavadora CAT 336','EXC-336','Rodrigo Salazar','observacion','Equipo operativo. Observación en sello hidráulico de cilindro de brazo, en monitoreo.','[{"cat": "Motor", "item": "Nivel y estado de aceite", "estado": "ok"}, {"cat": "Motor", "item": "Fugas y refrigerante", "estado": "ok"}, {"cat": "Motor", "item": "Correas y filtros", "estado": "ok"}, {"cat": "Hidráulico", "item": "Nivel y presión", "estado": "ok"}, {"cat": "Hidráulico", "item": "Sellos y mangueras", "estado": "observacion", "nota": "Leve fuga en sello de cilindro de brazo"}, {"cat": "Frenos", "item": "Frenos de aire / presión", "estado": "ok"}, {"cat": "Frenos", "item": "Fugas de aire", "estado": "ok"}, {"cat": "Tren de rodaje", "item": "Orugas / neumáticos y tensión", "estado": "ok"}, {"cat": "Tren de rodaje", "item": "Desgaste", "estado": "ok"}, {"cat": "Eléctrico", "item": "Batería y alternador", "estado": "ok"}, {"cat": "Eléctrico", "item": "Luces y tablero", "estado": "ok"}, {"cat": "Seguridad", "item": "Pasadores y estructura", "estado": "ok"}, {"cat": "Seguridad", "item": "Extintor y señalética", "estado": "ok"}]'::jsonb, current_date - 27),
      ('Excavadora CAT 336','EXC-336','Rodrigo Salazar','operativo','Inspección sin novedades.','[{"cat": "Motor", "item": "Nivel y estado de aceite", "estado": "ok"}, {"cat": "Motor", "item": "Fugas y refrigerante", "estado": "ok"}, {"cat": "Motor", "item": "Correas y filtros", "estado": "ok"}, {"cat": "Hidráulico", "item": "Nivel y presión", "estado": "ok"}, {"cat": "Hidráulico", "item": "Sellos y mangueras", "estado": "ok"}, {"cat": "Frenos", "item": "Frenos de aire / presión", "estado": "ok"}, {"cat": "Frenos", "item": "Fugas de aire", "estado": "ok"}, {"cat": "Tren de rodaje", "item": "Orugas / neumáticos y tensión", "estado": "ok"}, {"cat": "Tren de rodaje", "item": "Desgaste", "estado": "ok"}, {"cat": "Eléctrico", "item": "Batería y alternador", "estado": "ok"}, {"cat": "Eléctrico", "item": "Luces y tablero", "estado": "ok"}, {"cat": "Seguridad", "item": "Pasadores y estructura", "estado": "ok"}, {"cat": "Seguridad", "item": "Extintor y señalética", "estado": "ok"}]'::jsonb, current_date - 57),
      ('Camión Volvo A40G','CAM-A40','Marcela Tapia','operativo','Equipo operativo, sin observaciones.','[{"cat": "Motor", "item": "Nivel y estado de aceite", "estado": "ok"}, {"cat": "Motor", "item": "Fugas y refrigerante", "estado": "ok"}, {"cat": "Motor", "item": "Correas y filtros", "estado": "ok"}, {"cat": "Hidráulico", "item": "Nivel y presión", "estado": "ok"}, {"cat": "Hidráulico", "item": "Sellos y mangueras", "estado": "ok"}, {"cat": "Frenos", "item": "Frenos de aire / presión", "estado": "ok"}, {"cat": "Frenos", "item": "Fugas de aire", "estado": "ok"}, {"cat": "Tren de rodaje", "item": "Orugas / neumáticos y tensión", "estado": "ok"}, {"cat": "Tren de rodaje", "item": "Desgaste", "estado": "ok"}, {"cat": "Eléctrico", "item": "Batería y alternador", "estado": "ok"}, {"cat": "Eléctrico", "item": "Luces y tablero", "estado": "ok"}, {"cat": "Seguridad", "item": "Pasadores y estructura", "estado": "ok"}, {"cat": "Seguridad", "item": "Extintor y señalética", "estado": "ok"}]'::jsonb, current_date - 10);
  end if;
end $$;
