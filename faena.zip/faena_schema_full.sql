create extension if not exists pgcrypto;
drop view  if exists faena_v_pagos;
drop table if exists faena_solicitudes;
drop table if exists faena_parametros;
drop table if exists faena_mecanicos;
drop table if exists faena_clientes;
do $$ begin create type faena_gravedad as enum ('critica','alta','media');
exception when duplicate_object then null; end $$;
do $$ begin create type faena_estado_solicitud as enum
  ('pendiente','buscando','asignada','en_camino','en_terreno','completada','pagada','cancelada');
exception when duplicate_object then null; end $$;
do $$ begin create type faena_estado_mecanico as enum ('activo','pendiente','suspendido');
exception when duplicate_object then null; end $$;
do $$ begin create type faena_estado_pago as enum ('retenido','liberado');
exception when duplicate_object then null; end $$;
create sequence if not exists faena_folio_seq start 1001;
create table if not exists faena_clientes (
  id          uuid primary key default gen_random_uuid(),
  nombre      text not null,
  rubro       text,
  equipos     int  not null default 0,
  rating      numeric(2,1) default 5.0,
  created_at  timestamptz not null default now()
);
create table if not exists faena_mecanicos (
  id            uuid primary key default gen_random_uuid(),
  nombre        text not null,
  iniciales     text,
  color         text default '#1A56C4',
  especialidad  text,
  zona          text,
  rating        numeric(2,1) default 5.0,
  jobs          int  not null default 0,
  disponible    boolean not null default false,
  verificado    boolean not null default false,
  estado        faena_estado_mecanico not null default 'pendiente',
  rut           text,
  tarifa        int,
  certs         text,
  herramientas  text,
  especialidades text[],
  created_at    timestamptz not null default now()
);
alter table faena_mecanicos add column if not exists rut           text;
alter table faena_mecanicos add column if not exists tarifa        int;
alter table faena_mecanicos add column if not exists certs         text;
alter table faena_mecanicos add column if not exists herramientas  text;
alter table faena_mecanicos add column if not exists especialidades text[];
create table if not exists faena_solicitudes (
  id          uuid primary key default gen_random_uuid(),
  folio       text unique not null
              default ('SOL-' || lpad(nextval('faena_folio_seq')::text, 4, '0')),
  equipo      text not null,
  code        text,
  falla       text not null,
  gravedad    faena_gravedad not null default 'media',
  cliente_id  uuid references faena_clientes(id)  on delete set null,
  mecanico_id uuid references faena_mecanicos(id) on delete set null,
  estado      faena_estado_solicitud not null default 'pendiente',
  monto       int  not null default 0,
  eta_min     int,
  estado_pago faena_estado_pago,
  created_at  timestamptz not null default now()
);
create index if not exists idx_sol_estado   on faena_solicitudes(estado);
create index if not exists idx_sol_fecha     on faena_solicitudes(created_at);
create index if not exists idx_sol_cliente   on faena_solicitudes(cliente_id);
create index if not exists idx_sol_mecanico  on faena_solicitudes(mecanico_id);
create table if not exists faena_parametros (
  id            int primary key default 1,
  comision      int not null default 10,
  tarifa_visita int not null default 45000,
  tarifa_hora   int not null default 25000,
  radio_km      int not null default 30,
  updated_at    timestamptz not null default now(),
  constraint parametros_singleton check (id = 1)
);
insert into faena_parametros (id) values (1) on conflict (id) do nothing;
create or replace view faena_v_pagos with (security_invoker = true) as
select s.id, s.folio, s.cliente_id, s.mecanico_id, s.monto,
       round(s.monto * 0.10)::int as comision,
       round(s.monto * 0.90)::int as payout,
       s.estado_pago, s.created_at
from faena_solicitudes s
where s.estado in ('completada','pagada');
alter table faena_clientes    enable row level security;
alter table faena_mecanicos   enable row level security;
alter table faena_solicitudes enable row level security;
alter table faena_parametros  enable row level security;
drop policy if exists "demo read faena_clientes"    on faena_clientes;
drop policy if exists "demo insert faena_clientes"  on faena_clientes;
drop policy if exists "demo read faena_mecanicos"   on faena_mecanicos;
drop policy if exists "demo update faena_mecanicos" on faena_mecanicos;
drop policy if exists "demo insert faena_mecanicos" on faena_mecanicos;
drop policy if exists "demo delete faena_mecanicos" on faena_mecanicos;
drop policy if exists "demo all faena_solicitudes"  on faena_solicitudes;
drop policy if exists "demo all faena_parametros"   on faena_parametros;
create policy "demo read faena_clientes"    on faena_clientes    for select using (true);
create policy "demo insert faena_clientes"  on faena_clientes    for insert with check (true);
create policy "demo read faena_mecanicos"   on faena_mecanicos   for select using (true);
create policy "demo update faena_mecanicos" on faena_mecanicos   for update using (true) with check (true);
create policy "demo insert faena_mecanicos" on faena_mecanicos   for insert with check (true);
create policy "demo delete faena_mecanicos" on faena_mecanicos   for delete using (true);
create policy "demo all faena_solicitudes"  on faena_solicitudes for all    using (true) with check (true);
create policy "demo all faena_parametros"   on faena_parametros  for all    using (true) with check (true);
do $$
begin
  if not exists (select 1 from faena_clientes) then
    insert into faena_clientes (nombre, rubro, equipos, rating) values
      ('Constructora Andes Ltda.', 'Construcción', 3, 4.8),
      ('Minera Norte',             'Minería',      8, 4.6),
      ('Constructora Sur',         'Construcción', 5, 4.7),
      ('Áridos El Roble',          'Áridos',       2, 4.5);
  end if;
  if not exists (select 1 from faena_mecanicos) then
    insert into faena_mecanicos (nombre, iniciales, color, especialidad, zona, rating, jobs, disponible, verificado, estado, tarifa, certs, especialidades) values
      ('Rodrigo Salazar',  'RS', '#1A56C4', 'Frenos · Hidráulica',        'RM Poniente', 4.9, 212, true,  true,  'activo',     28000, 'CAT Certificado, SENCE, Frenos ABS', array['Frenos de aire','Sistema hidráulico']),
      ('Marcela Tapia',    'MT', '#15976A', 'Electrónica · Diagnóstico',  'RM Norte',    4.8, 156, true,  true,  'activo',     27000, 'Volvo Cert., Bosch ESI',             array['Falla electrónica']),
      ('Iván Quezada',     'IQ', '#E08600', 'Motor diésel · Transmisión', 'RM Sur',      4.7,  98, false, true,  'activo',     26000, 'Komatsu, Inyección diésel',          array['Motor diésel','Transmisión']),
      ('Pedro Cáceres',    'PC', '#7A5CC4', 'Tren de rodaje',             'Rancagua',    4.6,  64, true,  true,  'activo',     24000, 'CAT Certificado',                    array['Tren de rodaje']),
      ('Daniela Rojas',    'DR', '#0F8AA6', 'Hidráulica',                'RM Poniente', 4.9,  41, false, false, 'pendiente',  25000, 'SENCE, Hidráulica móvil',            array['Sistema hidráulico']),
      ('Sergio Maldonado', 'SM', '#94A3B5', 'Motor diésel',              'RM Centro',   4.3, 120, false, true,  'suspendido', 23000, 'Diésel',                             array['Motor diésel']);
  end if;
  if not exists (select 1 from faena_solicitudes) then
    with c as (select nombre, id from faena_clientes), m as (select nombre, id from faena_mecanicos)
    insert into faena_solicitudes (folio, equipo, code, falla, gravedad, cliente_id, mecanico_id, estado, monto, eta_min, estado_pago, created_at)
    select v.folio, v.equipo, v.code, v.falla, v.gravedad::faena_gravedad,
           (select id from c where nombre = v.cli),
           (select id from m where nombre = v.mec),
           v.estado::faena_estado_solicitud, v.monto, v.eta_min, v.pago::faena_estado_pago, v.created_at::timestamptz
    from (values
      ('SOL-1042','Excavadora CAT 336','EXC-336','Frenos de aire',   'critica','Constructora Andes Ltda.','Rodrigo Salazar','en_camino', 179850,    8, null,      '2026-06-27 09:41-04'),
      ('SOL-1041','Camión Volvo A40G',  'CAM-A40','Sistema hidráulico','alta', 'Minera Norte',            'Marcela Tapia',  'en_terreno',142000,    0, null,      '2026-06-27 08:10-04'),
      ('SOL-1040','Bulldozer Komatsu D65','BUL-D65','Falla electrónica','media','Constructora Sur',       null,             'buscando',   96000, null, null,      '2026-06-26 17:22-04'),
      ('SOL-1039','Excavadora CAT 320', 'EXC-320','Motor diésel',     'critica','Minera Norte',            null,             'pendiente', 168000, null, null,      '2026-06-26 11:05-04'),
      ('SOL-1038','Camión Volvo A40G',  'CAM-A40','Transmisión',      'alta',  'Constructora Andes Ltda.','Iván Quezada',   'completada',142000,    0, 'retenido','2026-06-25 15:48-04'),
      ('SOL-1037','Bulldozer Komatsu D65','BUL-D65','Tren de rodaje', 'media', 'Áridos El Roble',         'Pedro Cáceres',  'pagada',     96000,    0, 'retenido','2026-06-24 10:12-04'),
      ('SOL-1036','Excavadora CAT 336', 'EXC-336','Sistema hidráulico','alta', 'Constructora Andes Ltda.','Rodrigo Salazar','pagada',    179850,    0, 'liberado','2026-06-22 09:30-04'),
      ('SOL-1035','Camión Volvo A40G',  'CAM-A40','Falla electrónica','critica','Minera Norte',            'Marcela Tapia',  'pagada',    128000,    0, 'liberado','2026-06-20 14:03-04'),
      ('SOL-1034','Bulldozer Komatsu D65','BUL-D65','Motor diésel',   'media', 'Constructora Sur',        'Iván Quezada',   'pagada',     95500,    0, 'liberado','2026-06-18 16:40-04'),
      ('SOL-1033','Excavadora CAT 336', 'EXC-336','Frenos de aire',   'critica','Constructora Andes Ltda.','Rodrigo Salazar','pagada',    210000,    0, 'liberado','2026-06-15 08:55-04'),
      ('SOL-1032','Camión Volvo A40G',  'CAM-A40','Sistema hidráulico','alta', 'Minera Norte',            'Pedro Cáceres',  'cancelada',      0, null, null,      '2026-06-12 13:20-04'),
      ('SOL-1031','Bulldozer Komatsu D65','BUL-D65','Transmisión',    'media', 'Áridos El Roble',         'Marcela Tapia',  'pagada',    118000,    0, 'liberado','2026-06-08 11:11-04'),
      ('SOL-1030','Excavadora CAT 336', 'EXC-336','Motor diésel',     'alta',  'Constructora Andes Ltda.','Rodrigo Salazar','pagada',    165000,    0, 'liberado','2026-05-29 09:00-04'),
      ('SOL-1029','Camión Volvo A40G',  'CAM-A40','Frenos de aire',   'critica','Minera Norte',            'Iván Quezada',   'pagada',    188000,    0, 'liberado','2026-05-21 15:30-04')
    ) as v(folio, equipo, code, falla, gravedad, cli, mec, estado, monto, eta_min, pago, created_at);
    perform setval('faena_folio_seq', 1042);
  end if;
end $$;
update faena_mecanicos
   set tarifa = coalesce(tarifa, (round(rating * 4000) + 18000)::int),
       especialidades = coalesce(especialidades, string_to_array(especialidad, ' · ')),
       certs = coalesce(certs, 'Certificación vigente')
 where tarifa is null or especialidades is null or certs is null;
