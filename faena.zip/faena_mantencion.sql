create extension if not exists pgcrypto;

create table if not exists faena_planes (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  precio int not null,
  inspecciones_mes int not null default 1,
  descuento_pct int not null default 0,
  prioridad text not null default 'estandar',
  beneficios text[],
  orden int not null default 0
);

create table if not exists faena_suscripciones (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid references faena_clientes(id) on delete set null,
  equipo text not null,
  code text,
  plan_id uuid references faena_planes(id),
  estado text not null default 'activa',
  ultima_inspeccion date,
  proxima_inspeccion date,
  created_at timestamptz not null default now()
);

create index if not exists idx_susc_cliente on faena_suscripciones(cliente_id);
create index if not exists idx_susc_proxima on faena_suscripciones(proxima_inspeccion);

alter table faena_solicitudes add column if not exists tipo text not null default 'servicio';
alter table faena_solicitudes add column if not exists suscripcion_id uuid;

alter table faena_planes        enable row level security;
alter table faena_suscripciones enable row level security;

drop policy if exists "demo read planes"        on faena_planes;
drop policy if exists "demo all suscripciones"  on faena_suscripciones;
create policy "demo read planes"       on faena_planes        for select using (true);
create policy "demo all suscripciones" on faena_suscripciones for all    using (true) with check (true);

do $$
begin
  if not exists (select 1 from faena_planes) then
    insert into faena_planes (nombre, precio, inspecciones_mes, descuento_pct, prioridad, beneficios, orden) values
      ('Preventivo Básico', 139000, 1, 5,  'estandar',
        array['1 inspección mensual en terreno','Checklist documentado por equipo','Prioridad estándar','5% dcto en reparaciones'], 1),
      ('Preventivo Pro',    259000, 2, 10, 'alta',
        array['2 inspecciones + cambio de fluidos','Checklist + reporte de salud','Despacho prioritario < 4 h','10% dcto en reparaciones'], 2),
      ('Flota Total',       129000, 2, 12, 'alta',
        array['Todo lo de Pro','Gestor de cuenta dedicado','Ventana de atención 24/7','Precio por equipo (desde 3)'], 3);
  end if;
end $$;

do $$
declare cid uuid; ppro uuid; pbas uuid;
begin
  select id into cid  from faena_clientes where nombre = 'Constructora Andes Ltda.' limit 1;
  select id into ppro from faena_planes   where nombre = 'Preventivo Pro' limit 1;
  select id into pbas from faena_planes   where nombre = 'Preventivo Básico' limit 1;
  if not exists (select 1 from faena_suscripciones) then
    insert into faena_suscripciones (cliente_id, equipo, code, plan_id, estado, ultima_inspeccion, proxima_inspeccion) values
      (cid, 'Excavadora CAT 336', 'EXC-336', ppro, 'activa', current_date - 27, current_date + 3),
      (cid, 'Camión Volvo A40G',  'CAM-A40', pbas, 'activa', current_date - 10, current_date + 20);
  end if;
end $$;
